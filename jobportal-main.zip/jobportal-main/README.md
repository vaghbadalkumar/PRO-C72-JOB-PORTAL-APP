# PRO-C72-JOB-PORTAL-APP
In Class 72, You Learned To Use Keyboardavoidingview And Toastandroid To Avoid Textinput Overlap With The Keyboard Layout And Display A Submission Alert. In This Project, You Have To Practice And Apply What You Have Learned In Class To Create A Job Portal App.
